
setTimeout(() => {
  document.getElementById('jumpscare').style.display = 'flex';
  document.getElementById('scream').play();
}, 5000); // Delay 5 detik sebelum jumpscare
